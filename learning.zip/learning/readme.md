
##Requirement 1
#### POST: http://localhost:8080/library/save
{

    "libraryId" : "101",
    "libraryName" : "Reston Library",
    "books" :[
        {
        "bookId" : "85u9dd",
        "bookName" : "The Lord of the Rings by J.J.R.Tolkien"          
        },
      {
        "bookId" : "1948uk",
        "bookName" : "The 7 Habits of Highly Effective People" 
      },
      {
        "bookId" : "Ijhu786",
        "bookName" : "The Power of Positive Thinking" 
      }      
    ]     

}
{

    "libraryId" : "102",
    "libraryName" : "Gum Spring Library",
    "books" :[
        {
        "bookId" : "98jkuiy",
        "bookName" : "How to win friends and influence people"          
        }  
    ]     

}
### Requirement 2
#### Display all the books in each library
#### GET: http://localhost:8080/library/findAllLibraries
#### Response 
[
{
"libraryId": 101,
"libraryName": "Reston Library",
"books": [
{
"bookId": "1948uk",
"bookName": "The 7 Habits of Highly Effective People"
},
{
"bookId": "85u9dd",
"bookName": "The Lord of the Rings by J.J.R.Tolkien"
},
{
"bookId": "Ijhu786",
"bookName": "The Power of Positive Thinking"
}
]
},
{
"libraryId": 102,
"libraryName": "Gum Spring Library",
"books": [
{
"bookId": "98jkuiy",
"bookName": "How to win friends and influence people"
}
]
}
]

### Requirement 3
#### Total count of books in each library

#### GET : http://localhost:8080/library/booksCount

[
{
"libraryId": 101,
"booksCount": 3
},
{
"libraryId": 102,
"booksCount": 1
}
]